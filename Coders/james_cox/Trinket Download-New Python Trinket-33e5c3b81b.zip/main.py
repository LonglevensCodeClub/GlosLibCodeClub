import pygal
 
piechart = pygal.Bar()
piechart.title = 'Favourite Pets'
piechart.add('Dog',6)
piechart.add('Cat',3) 
piechart.add('Hamster',3)
piechart.add('Fish',2)
piechart.add('Snake',1)
piechart.render()
